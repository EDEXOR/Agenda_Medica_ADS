
  <!-- Page Content -->
  <div class="container">
    <h1>Panel administrativo</h1>
    <div class="row text-center">
    <!-- Page Features -->
    <div class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="http://placehold.it/500x325" alt="">
          <div class="card-body">
            <h4 class="card-title">USUARIOS</h4>
            <p class="card-text">Administracion de usuarios</p>
          </div>
          <div class="card-footer">
            <a href="../usuarios/index.php"class="btn btn-primary stretched-link">Ir al panel</a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="http://placehold.it/500x325" alt="">
          <div class="card-body">
            <h4 class="card-title">CLIENTES</h4>
            <p class="card-text">Administracion de clientes</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">Ir al panel</a>
          </div>
        </div>
      </div><div class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="http://placehold.it/500x325" alt="">
          <div class="card-body">
            <h4 class="card-title">OPCION 3</h4>
            <p class="card-text">texto descriptivo</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">texto descriptivo</a>
          </div>
        </div>
      </div>
      
    </div>

  </div>
  <!-- /.container -->

