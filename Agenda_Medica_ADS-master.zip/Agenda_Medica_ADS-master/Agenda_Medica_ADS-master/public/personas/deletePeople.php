<?php
require_once("../../app/views/template/template.php"); 
Page::templateHeader("Eliminar persona");
require_once("../../app/views/personas/DeletePeople_view.php");
Page::templateFooter();
?>