
  <!-- Page Content -->
  <div class="container">
     <br>
      <br>
    <!-- Jumbotron Header -->
    <header class="jumbotron my-4" id="header">
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>

      
    </header>
    <header class="jumbotron my-4" >
      <h1 class="display-3">Bienvenidos</h1>
      <h4 class="display-5">Sistema clinicas MERC</h4>
      <a href="login.php" class="btn btn-primary btn-lg">INICIAR SESION</a>
    </header>
    <!-- Page Features -->
    

  </div>
  <!-- /.container -->
  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3876.124481545956!2d-89.20807188516997!3d13.710909690373931!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8f6331003765f277%3A0xa2b4a904b00aa835!2sCl%C3%ADnica%20M%C3%A9dica%20MerBel!5e0!3m2!1sen!2ssv!4v1583462954965!5m2!1sen!2ssv" width="100%" height="350" frameborder="0" style="border:0; margin: 0;" allowfullscreen=""></iframe>