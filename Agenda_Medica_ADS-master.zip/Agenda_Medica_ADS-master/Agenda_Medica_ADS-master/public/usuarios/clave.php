<?php
require_once("../../app/views/template/template.php"); 
Page::templateHeader("Actualizar usuario Clave");
require_once("../../app/controllers/usuarios/clave_controller.php");
Page::templateFooter();
?>