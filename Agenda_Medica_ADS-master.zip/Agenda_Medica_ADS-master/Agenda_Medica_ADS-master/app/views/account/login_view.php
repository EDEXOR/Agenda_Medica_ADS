<!-- Page Content -->
<div class="container">
  <br>
  <br>
  <!-- Jumbotron Header -->
  <header class="jumbotron my-4" id="header">
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
  </header>
  <!-- Page Features -->
  <header class="jumbotron my-4">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h2>INICIO DE SESION</h2>

          <form role="form" method="post">
            <div class="form-group">
              <label for="username">Nombre de usuario o email</label>
              <input type="text" class="form-control" id="username" name="username" placeholder="Nombre de usuario">
            </div>
            <div class="form-group">
              <label for="password">Contrase&ntilde;a</label>
              <input type="password" class="form-control" id="password" name="password" placeholder="Contrase&ntilde;a">
            </div>

            <button type="submit" class="btn btn-primary" name="login">Acceder</button>
          </form>
        </div>
      </div>
    </div>
    <!--<script src="js/valida_login.js"></script>-->

  </header>
</div>

</div>
<!-- /.container -->