<?php
require_once("../../app/views/template/template.php"); 
Page::templateHeader("Crear persona");
require_once("../../app/views/personas/CreatePeople_view.php");
Page::templateFooter();
?>