<?php
require_once("../../app/views/template/template.php"); 
Page::templateHeader("Panel Administrador");
require_once("../../app/controllers/inicio/panel_controller.php");
Page::templateFooter();
?>